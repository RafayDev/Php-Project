<html>
<head>
  
 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<style>
#menu ul{
list-style:none;
margin : 0px px 0px 250px; 
}
#menu ul li{
width:300px;
height:23px;

text-align:center;
padding-top:50x;
float: left;
}
#menu ul li a{
	color:white;
	text-decoration:none;
	padding-right:5px;
	text-align:center;
}
.linee{
		display: inline-block;
		margin : 20px 0px 0px 0px;
}
.mySlides {display:none;}
.tab-content {
    border: 10px solid white;
	border-decoration:shadow;
   
}
</style>
</head>
<body  style="background-color:white;">
  <div class="row" >
  <div class="col-md-6" >
 <a href="Home.html"> <img  style="margin : 20px 0px 0px 20px;" src="Img/Logo.png" width="150" height="140" ></a>
  </div>
    <div class="col-md-6 linee " >
	
	<h1 style="margin:50px 0px 0px 200px; font-style: oblique;"><b><u>DASHBOARD</u></b></h1>

  
  </div>
  </div>
	<div class="row" style="background-color:black">
	<div class="col-md-12"  >
		<div id="menu" >
<ul>

<li> <a href="dashboard.php"> <b> Home</b> </li>
<li> <a href="addP.php" > <b>Add Product</b> </li>
<li> <a href="viewP.php"> <b>View/Update</b></li>
<li> <a href="logout.php"> <b>Logout </b></li></a>
</ul>

</div>
  </div>

	
	  </div>
	    <h2 style="margin:20px 0px 0px 50px"><b><u>Welcome to Kipo Dashboard</u></b></h2>
		<p style="margin:20px 0px 0px 100px"><b> Through the Dashboard you can use following Features :</b> <br></br>
		<b>1.</b> Add Product <br>
		<b>2.</b> View Product <br> <b>3.</b> Delete Product <br> <b>4.</b> Edit Product
		
		
		</p>
		<p style="margin:20px 0px 0px 50px"><br><br><br> <b>Enjoy These Features...........</b></p>
		
		
			<div class="row" style="background-color:black; margin:100px 0px 0px 0px" >
		   <div class="col-md-6" >
<p style="margin : 0px 0px 0px 28px; color:white;"><br>Copyright license@2020</br></p>
		</div>
	   <div class="col-md-6 linee" style="background-color:black" >
 <a href="https://www.google.com"> <img style="margin : 0px 0px 0px 300px;" src="Img/g.png" width="30" height="30"></a>
 <a href="https://web.facebook.com/?_rdc=1&_rdr"> <img  src="Img/Facebook.png" width="30" height="30"> </a>
 <a href="https://www.twitter.com"><img  src="Img/Twiter.png" width="30" height="30"></a>
  <a href="https://www.instagram.com"><img  src="Img/insta.png" width="30" height="30"></a>
<a href="https://www.linkedin.com" > <img  src="Img/download.png" width="30" height="30"></a>
   </div>
  </div>
	  
	  
	  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

	  </body>
	  </html>