<?php session_start(); ?>

<?php
if(!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
?>

<?php

include_once("connection.php");


$result = mysqli_query($mysqli, "SELECT * FROM product WHERE Login_Id=".$_SESSION['id']." ORDER BY id DESC");
?>
<html>
<head>
  
 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<style>
#menu ul{
list-style:none;
margin : 0px px 0px 250px; 
}
#menu ul li{
width:300px;
height:23px;

text-align:center;
padding-top:50x;
float: left;
}
#menu ul li a{
	color:white;
	text-decoration:none;
	padding-right:5px;
	text-align:center;
}
.linee{
		display: inline-block;
		margin : 20px 0px 0px 0px;
}
.mySlides {display:none;}
.tab-content {
    border: 10px solid white;
	border-decoration:shadow;
 .size{
	 width="30"; 
	 height="30";
 }  
}
</style>
</head>
<body  style="background-color:white;">
  <div class="row" >
  <div class="col-md-6" >
 <a href="Home.html"> <img  style="margin : 20px 0px 0px 20px;" src="Img/Logo.png" width="150" height="140" ></a>
  </div>
    <div class="col-md-6 linee " >
	
	<h1 style="margin:50px 0px 0px 200px; font-style: oblique;"><b><u>DASHBOARD</u></b></h1>

  
  </div>
  </div>
	<div class="row" style="background-color:black">
	<div class="col-md-12"  >
		<div id="menu" >
<ul>

<li> <a href="dashboard.php"> <b> Home</b> </li>
<li> <a href="addP.php" > <b>Add Product</b> </li>
<li> <a href="viewP.php"> <b>View/Update</b></li>
<li> <a href="logout.php"> <b>Logout </b></li></a>
</ul>

</div>
  </div>
  </div>
  <div style="margin:50px 0px 0px 20px;">
  	<table width='80%' border=0>
		<tr  bgcolor='#CCCCCC'>
			<td>Id</td>
			<td>Name</td>
			<td>Price (Pkr)</td>
			<td>Code</td>
			<td>InStock</td>
			<td>Discount</td>
			<td>Size</td>
			<td>Details</td>
			<td>Image</td>
			<td>Update</td>
		</tr>
		<?php
		while($res = mysqli_fetch_assoc($result)) {		
		?>
			 <tr>
			 <td><?php echo  $res['Id']?></td>
			<td><?php echo  $res['Name']?></td>
			 <td><?php echo $res['Price'] ?></td>
			<td><?php echo $res['Code'] ?></td>
			<td><?php echo $res['Instock'] ?></td>
			<td><?php echo $res['Discount'] ?></td>
			<td><?php echo $res['Size'] ?></td>
			<td><?php echo $res['Details'] ?></td>
			<td> <img src="<?php echo $res['Image_Path'] ?>" width="30" height="30"> </td>
<?php	echo "<td><a href=\"edit.php?Id=$res[Id]\">Edit</a> | <a href=\"delete.php?Id=$res[Id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";		?>
		<?php	
		}
		?>
	</table>	
	</div>
</body>
  
  
  
  
  </body>
  </html>