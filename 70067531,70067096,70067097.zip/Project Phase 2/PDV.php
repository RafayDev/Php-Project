<?php session_start(); ?>
<?php
include("connection.php");


?>
<html>
<head>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
  <style>
#menu ul{
list-style:none;
margin : 0px px 0px 250px; 
}
#menu ul li{
width:300px;
height:23px;
background-color:black;
border:1px solid black;
text-align:center;
padding-top:50x;
float: left;
}
#menu ul li a{
	color:white;
	text-decoration:none;
	padding-right:5px;
	text-align:center;
}
.linee{
		display: inline-block;
		margin : 20px 0px 0px 0px;
}
.tab-content {
    border: 10px solid white;
	border-decoration:shadow;
   
}
</style>
</head>
<body  style="background-color:white;">
  <div class="row" >
  <div class="col-md-6" >
 <a href="Home.html"> <img  style="margin : 20px 0px 0px 20px;" src="Img/Logo.png" width="150" height="140" ></a>
  </div>
    <div class="col-md-6 linee" >
  <img style="margin : 0px 0px 0px 300px;" src="Img/g.png" width="30" height="30">
  <img  src="Img/Facebook.png" width="30" height="30">
  <img  src="Img/Twiter.png" width="30" height="30">
  <img  src="Img/insta.png" width="30" height="30">
  <img  src="Img/download.png" width="30" height="30">
  
  </div>
  </div>
    	<div class="row"  style="background-color:black;">
	<div class="col-md-12"  >
		<div id="menu" >
<ul>

<li> <a href="Home.html"> <b> Home</b> </li>
<li> <a href="About.html" > <b>About US</b> </li>
<li> <a href="Products.php"> <b>Products </b></li>
<li> <a href="Contract.html"> <b>Contract Us </b></li></a>
</ul>

</div>
  </div>
	
	  </div>
	  <?php
	  include("connection.php");
//getting id from url
$id = $_GET['Id'];
$ido= substr($id,0,-1);
$result=mysqli_query($mysqli, "SELECT * FROM `product` WHERE Id=$ido");
while($res = mysqli_fetch_array($result))
{
		$name = $res['Name'];
	$price = $res['Price'];
	$code = $res['Code'];
	$instock = $res['Instock'];
	$discount = $res['Discount'];
	$size = $res['Size'];
	$detail = $res['Details'];	
	$image = $res['Image_Path'];
}




?>
	  	  <h3 style="margin:20px 0px 0px 80px; color:black;" ><b><?php echo $name; ?></b></h3>
		  	    <div class="row" >
  <div class="col-md-2" >
  <img  style="margin : 50px 0px 0px 50px; border: 3px solid black;" src="<?php echo $image; ?>" width="200" height="150" >
  </div>
    <div class="col-md-4 " >
 <p style="margin : 50px 0px 0px 100px; color:black">
  Product Price:<?php echo $price; ?>
  <br>Product Code:<?php echo $code; ?></br>
  Product In Stock: <?php echo $instock; ?>
  <br>Product Discount:<?php echo $discount; ?>%</br>
  
  
 </p>
 	  
  
  </div>
  </div>
    <h4 style="margin:20px 0px 0px 80px; color:black;" ><b>Product Details:</b></h4>
   <p style="margin : 20px 0px 0px 100px; color:black">
<?php echo $detail; ?></p>

 		<div class="row" style="background-color:black; margin : 200px 0px 0px 0px;" >
		   <div class="col-md-6" >
<p style="margin : 0px 0px 0px 28px; color:white;"><br>Copyright license@2020</br></p>
		</div>
	   <div class="col-md-6 linee" style="background-color:black;" >
 <a href="https://www.google.com"> <img style="margin : 0px 0px 0px 300px;" src="Img/g.png" width="30" height="30"></a>
 <a href="https://web.facebook.com/?_rdc=1&_rdr"> <img  src="Img/Facebook.png" width="30" height="30"> </a>
 <a href="https://www.twitter.com"><img  src="Img/Twiter.png" width="30" height="30"></a>
  <a href="https://www.instagram.com"><img  src="Img/insta.png" width="30" height="30"></a>
<a href="https://www.linkedin.com" > <img  src="Img/download.png" width="30" height="30"></a>
   </div>
  </div>
		  </body>
		  </html>