<?php session_start(); ?>
<html>
<head>
  
 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

<style>
#menu ul{
list-style:none;
margin : 0px px 0px 250px; 
}
#menu ul li{
width:300px;
height:23px;

text-align:center;
padding-top:50x;
float: left;
}
#menu ul li a{
	color:white;
	text-decoration:none;
	padding-right:5px;
	text-align:center;
}
.linee{
		display: inline-block;
		margin : 20px 0px 0px 0px;
}
.mySlides {display:none;}
.tab-content {
    border: 10px solid white;
	border-decoration:shadow;
   
}
</style>
</head>
<body  style="background-color:white;">
  <div class="row" >
  <div class="col-md-6" >
 <a href="Home.html"> <img  style="margin : 20px 0px 0px 20px;" src="Img/Logo.png" width="150" height="140" ></a>
  </div>
    <div class="col-md-6 linee" >
  <img style="margin : 0px 0px 0px 300px;" src="Img/g.png" width="30" height="30">
  <img  src="Img/Facebook.png" width="30" height="30">
  <img  src="Img/Twiter.png" width="30" height="30">
  <img  src="Img/insta.png" width="30" height="30">
  <img  src="Img/download.png" width="30" height="30">
  
  </div>
  </div>
	<div class="row" style="background-color:black">
	<div class="col-md-12"  >
		<div id="menu" >
<ul>

<li> <a href="Home.html"> <b> Home</b> </li>
<li> <a href="About.html" > <b>About US</b> </li>
<li> <a href="Products.html"> <b>Products </b></li>
<li> <a href="Contract.html"> <b>Contract Us </b></li></a>
</ul>

</div>
  </div>
	
	  </div>
		
			  	<div class="row" style="margin:50px 0px 0px 100px;  ">
		<div class="col-md-2"  >
		<?php
include("connection.php");

if(isset($_POST['submit'])) {
	$user =  $_POST['username'];
	$pass = $_POST['password'];

	if($user == "" || $pass == "") {
		echo "Either username or password field is empty.";
		echo "<br/>";
		echo "<a href='login.php'>Go back</a>";
	} else {
		$result = mysqli_query($mysqli, "SELECT * FROM login WHERE username='$user' AND password='$pass'")
					or die("Could not execute the select query.");
		
		$row = mysqli_fetch_assoc($result);
		
		if(is_array($row) && !empty($row)) {
			$validuser = $row['username'];
			$_SESSION['valid'] = $validuser;
			$_SESSION['name'] = $row['name'];
			$_SESSION['id'] = $row['id'];
		} else {
			echo "<p>Invalid username or password.<p>";
			echo "<br/>";
			echo "<a href='login.php'>Go back</a>";
		}

		if(isset($_SESSION['valid'])) {
			header('Location: dashboard.php');			
		}
	}
} 
?>
	<h2><b><u>Login</u><b></h2>
	<br></br>
	<form name="form1" method="post" action="">
		<table width="75%" border="0">
			<tr> 
				<td width="10%"><b>UserName:</b></td>
				<td><input type="text" name="username"></td>
			</tr>
				<tr> 
				<td>&nbsp;</td>
				
				
			</tr>
			<tr> 
				<td><b>Password :</b></td>
				<td><input type="password" name="password"></td>
			</tr>
			<tr> 
				<td>&nbsp;</td>
				
				
			</tr>
			<tr> 
				<td>&nbsp;</td>
				
				<td><input  style="background-color:black; color:white; border-radius: 12px; padding: 2px 32px; " type="submit" name="submit" value="Login"></td>
			</tr>
		</table>
	</form>
<?php

?>
		</div>
		</div>

	  	<div class="row" style="background-color:black; margin:200px 0px 0px 0px" >
		   <div class="col-md-6" >
<p style="margin : 0px 0px 0px 28px; color:white;"><br>Copyright license@2020</br></p>
		</div>
	   <div class="col-md-6 linee" style="background-color:black" >
 <a href="https://www.google.com"> <img style="margin : 0px 0px 0px 300px;" src="Img/g.png" width="30" height="30"></a>
 <a href="https://web.facebook.com/?_rdc=1&_rdr"> <img  src="Img/Facebook.png" width="30" height="30"> </a>
 <a href="https://www.twitter.com"><img  src="Img/Twiter.png" width="30" height="30"></a>
  <a href="https://www.instagram.com"><img  src="Img/insta.png" width="30" height="30"></a>
<a href="https://www.linkedin.com" > <img  src="Img/download.png" width="30" height="30"></a>
   </div>
  </div>
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	  </body>
	  </html>