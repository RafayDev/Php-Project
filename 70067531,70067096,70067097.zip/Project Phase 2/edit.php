<?php session_start(); ?>

<?php
if(!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
?>
<?php
error_reporting(E_ALL & ~E_NOTICE);


$id = $_GET['Id'];
include("connection.php");
$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

if(isset($_POST["update"])) {
  $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
  if($check !== false) {
    echo "File is an image - " . $check["mime"] . ".";
    $uploadOk = 1;
  } else {
    echo "File is not an image.";
    $uploadOk = 0;
  }
}




if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
 // echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
  $uploadOk = 0;
}


if ($uploadOk == 0) {
  //echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
    echo "The file ". htmlspecialchars( basename( $_FILES["fileToUpload"]["name"])). " has been uploaded.";
	
  } else {
    echo "Sorry, there was an error uploading your file.";
  }
}
?>
<?php
// including the database connection file
include_once("connection.php");
if(isset($_POST['update']))
{	
	$id = $_POST['id'];
	$name = $_POST['name'];
	$price = $_POST['price'];
	$code = $_POST['code'];
	$instock = $_POST['instock'];
	$discount = $_POST['discount'];
	$size = $_POST['size'];
	$detail = $_POST['detail'];	
	
	// checking empty fields
	if( empty($name) || empty($price)||empty($code)||empty($instock)||empty($discount)||empty($size)||empty($detail)){
				
	
		if(empty($name)) {
			echo "<font color='red'>Name field is empty.</font><br/>";
		}
		
		if(empty($price)) {
			echo "<font color='red'>Price field is empty.</font><br/>";
		}
				if(empty($code)) {
			echo "<font color='red'>Code field is empty.</font><br/>";
		}
						if(empty($instock)) {
			echo "<font color='red'>Stock field is empty.</font><br/>";
		}
						if(empty($discount)) {
			echo "<font color='red'>Discount field is empty.</font><br/>";
		}
						if(empty($size)) {
			echo "<font color='red'>Size field is empty.</font><br/>";
		}
						if(empty($detail)) {
			echo "<font color='red'>Detail field is empty.</font><br/>";
		}
	
		

		echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";	
	} else {	

		$result = mysqli_query($mysqli, "UPDATE product SET Name='$name', Price='$price', Code='$code' , Instock='$instock' , Discount='$discount' , Size='$size' , Details='$detail', Image_Path='$target_file' WHERE Id=$id");

		header("Location: viewP.php");
	}
}
?>
<?php

$id = $_GET['Id'];


$result = mysqli_query($mysqli, "SELECT * FROM product WHERE Id=$id");
while($res = mysqli_fetch_array($result))
{
		$name = $res['Name'];
	$price = $res['Price'];
	$code = $res['Code'];
	$instock = $res['Instock'];
	$discount = $res['Discount'];
	$size = $res['Size'];
	$detail = $res['Details'];	
	$image = $res['Image_Path'];
}
?>
<html>
<head>	

</head>

<body>
  <div class="row" >
  <div class="col-md-6" >
 <a href="Home.html"> <img  style="margin : 20px 0px 0px 20px;" src="Img/Logo.png" width="150" height="140" ></a>
  </div>
    <div class="col-md-6 linee " >
	
	<h1 style="margin:50px 0px 0px 200px; font-style: oblique;"><b><u>Product Edits</u></b></h1>

  
  </div>
  </div>
	<br/><br/>
	
	<form name="form1" method="post" action="edit.php"  enctype="multipart/form-data">
		<table border="0">
		<tr> 
				<td>Image</td>
				<td><input type="file" name="fileToUpload" id="fileToUpload" value="<?php echo $image;?>"> </td>
			</tr>
			<tr> 
				<td>Name</td>
				<td><input type="text" name="name" value="<?php echo $name;?>"></td>
			</tr>
			<tr> 
				<td>Price</td>
				<td><input type="text" name="price" value="<?php echo $price;?>"></td>
			</tr>
			<tr> 
				<td>Code</td>
				<td><input type="text" name="code" value="<?php echo $code;?>"></td>
			</tr>
			<tr> 
				<td>InStock</td>
				<td><input type="text" name="instock" value="<?php echo $instock;?>"></td>
			</tr>
			<tr> 
				<td>Discount</td>
				<td><input type="text" name="discount" value="<?php echo $discount;?>"></td>
			</tr>
			<tr> 
				<td>Size</td>
				<td><input type="text" name="size" value="<?php echo $size;?>"></td>
			</tr>
			<tr> 
				<td>Details</td>
				<td><textarea id="detail" name="detail"  rows="4" cols="50"> <?php echo $detail;?> </textarea></td>
			</tr>
			<tr>
				<td><input type="hidden" name="id" value=<?php echo $_GET['Id'];?>></td>
				<td><input  style="background-color:black; color:white; border-radius: 12px; padding: 2px 32px; " type="submit" name="update" value="Update"></td>
			</tr>
		</table>
	</form>
</body>
</html>
