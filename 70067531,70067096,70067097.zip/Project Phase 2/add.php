<?php session_start(); ?>


<html>
<head>
</head>

<body>
<?php

include("connection.php");
include("upload.php");

if(isset($_POST['Submit'])) {	

	$name = $_POST['name'];
	$price = $_POST['price'];
	$code = $_POST['code'];
	$instock = $_POST['instock'];
	$discount = $_POST['discount'];
	$size = $_POST['size'];
	$detail = $_POST['detail'];
	$loginId = $_SESSION['id'];
		
	// checking empty fields
	if( empty($name) || empty($price)||empty($code)||empty($instock)||empty($discount)||empty($size)||empty($detail)){
				
	
		if(empty($name)) {
			echo "<font color='red'>Name field is empty.</font><br/>";
		}
		
		if(empty($price)) {
			echo "<font color='red'>Price field is empty.</font><br/>";
		}
				if(empty($code)) {
			echo "<font color='red'>Code field is empty.</font><br/>";
		}
						if(empty($instock)) {
			echo "<font color='red'>Stock field is empty.</font><br/>";
		}
						if(empty($discount)) {
			echo "<font color='red'>Discount field is empty.</font><br/>";
		}
						if(empty($size)) {
			echo "<font color='red'>Size field is empty.</font><br/>";
		}
						if(empty($detail)) {
			echo "<font color='red'>Detail field is empty.</font><br/>";
		}
	
		

		echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
	} else { 

			

		$result = mysqli_query($mysqli, "INSERT INTO product(Name,Price,Code,Instock,Discount,Size,Details,Image_Path,Login_Id) VALUES('$name','$price','$code','$instock','$discount','$size','$detail', '$target_file', '$loginId')");
		

		echo "<font color='green'>Data added successfully.";
				echo "<br/><a href='addP.php'>Go Back</a>";
	}
}
?>
</body>
</html>
