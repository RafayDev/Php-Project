<?php session_start(); ?>

<?php
if(!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
?>

<?php

include("connection.php");


$id = $_GET['Id'];

$result=mysqli_query($mysqli, "DELETE FROM product WHERE Id=$id");


header("Location:viewP.php");
?>

