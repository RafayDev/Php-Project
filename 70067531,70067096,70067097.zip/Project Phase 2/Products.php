

<?php

include_once("connection.php");

$result = mysqli_query($mysqli, "SELECT * FROM product Where Instock='Y'");
?>
<html>
<head>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
  <style>
#menu ul{
list-style:none;
margin : 0px px 0px 250px; 
}
#menu ul li{
width:300px;
height:23px;
background-color:black;
border:1px solid black;
text-align:center;
padding-top:50x;
float: left;
}
#menu ul li a{
	color:white;
	text-decoration:none;
	padding-right:5px;
	text-align:center;
}
.linee{
		display: inline-block;
		margin : 20px 0px 0px 0px;
}
.tab-content {
    border: 10px solid white;
	border-decoration:shadow;
   
}
</style>
</head>
<body  style="background-color:white;">
  <div class="row" >
  <div class="col-md-6" >
 <a href="Home.html"> <img  style="margin : 20px 0px 0px 20px;" src="Img/Logo.png" width="150" height="140" ></a>
  </div>
    <div class="col-md-6 linee" >
  <img style="margin : 0px 0px 0px 300px;" src="Img/g.png" width="30" height="30">
  <img  src="Img/Facebook.png" width="30" height="30">
  <img  src="Img/Twiter.png" width="30" height="30">
  <img  src="Img/insta.png" width="30" height="30">
  <img  src="Img/download.png" width="30" height="30">
    <a   href="login.php"> <img  src="Img/login.png" width="30" height="30"> <b>Login|Dashboard</b></a>
  </div>
  </div>
    	<div class="row"  style="background-color:black;">
	<div class="col-md-12"  >
		<div id="menu" >
<ul>

<li> <a href="Home.html"> <b> Home</b> </li>
<li> <a href="About.html" > <b>About US</b> </li>
<li> <a href="Products.php"> <b>Products </b></li>
<li> <a href="Contract.html"> <b>Contract Us </b></li></a>
</ul>

</div>
  </div>
	
	  </div>
	  	  <h1 style="margin:20px 0px 0px 50px; color:black;" ><b>Our Products</b></h1>
		  	<?php
		while($res = mysqli_fetch_assoc($result)) {		
		?>
		  	<div class="row" style="margin : 0px 0px 0px 0px">
	<div class="col-md-4 tab-content" >
<?php echo"<a href=\"PDV.php?Id=$res[Id]]\">"?>	<img style="margin : 0px 0px 0px 200px; border: 3px solid black;" src="<?php echo $res['Image_Path'] ?>" width="150" height="140"></a>
	<p style="margin : 0px 0px 0px 228px"> <?php echo  $res['Name']?></p>
	
	</div>

<?php	
		}
		?>
	</div>
	
		<div class="row" style="background-color:black; margin : 300px 0px 0px 0px;" >
		   <div class="col-md-6" >
<p style="margin : 0px 0px 0px 28px; color:white;"><br>Copyright license@2020</br></p>
		</div>
	   <div class="col-md-6 linee" style="background-color:black;" >
 <a href="https://www.google.com"> <img style="margin : 0px 0px 0px 300px;" src="Img/g.png" width="30" height="30"></a>
 <a href="https://web.facebook.com/?_rdc=1&_rdr"> <img  src="Img/Facebook.png" width="30" height="30"> </a>
 <a href="https://www.twitter.com"><img  src="Img/Twiter.png" width="30" height="30"></a>
  <a href="https://www.instagram.com"><img  src="Img/insta.png" width="30" height="30"></a>
<a href="https://www.linkedin.com" > <img  src="Img/download.png" width="30" height="30"></a>
   </div>
  </div>
</body>
</html>